# GlassTV Launcher

An Apple TV–inspired Android TV launcher for the MXQ Pro 4K 5G (Android 5.1, API 22).
Light glass panel aesthetic with smooth D-pad navigation, YouTube recommendations, and a 5-app dock.

## Requirements

- Android Studio 3.5 or newer
- Android SDK with API 22 (Android 5.1) and API 28 (compile SDK)
- Java 7+

## Project Structure

```
app/src/main/
├── AndroidManifest.xml
├── java/com/glasstv/launcher/
│   ├── LauncherActivity.java           # Main home screen
│   ├── SettingsActivity.java           # Settings screen
│   ├── WallpaperPickerActivity.java    # Wallpaper chooser
│   ├── FavoritesManagerActivity.java   # Dock app manager
│   ├── adapters/
│   │   ├── VideoAdapter.java           # YouTube row adapter
│   │   ├── FavoritesAdapter.java       # Dock adapter
│   │   ├── AppPickerAdapter.java       # App list adapter
│   │   └── WallpaperPickerAdapter.java # Wallpaper grid adapter
│   ├── managers/
│   │   ├── FavoritesManager.java       # Dock persistence (SharedPrefs)
│   │   └── WallpaperManager.java       # Wallpaper persistence
│   ├── models/
│   │   ├── VideoItem.java              # YouTube video model
│   │   └── AppItem.java                # Installed app model
│   ├── receivers/
│   │   └── BootReceiver.java           # Auto-start on boot
│   ├── services/
│   │   └── YouTubeRecommendationService.java  # YouTube Data API v3
│   ├── utils/
│   │   ├── TimeUtils.java              # 12-hour clock + date formatting
│   │   └── ThumbnailCache.java         # LRU bitmap cache
│   └── views/
│       ├── DpadLinearLayout.java       # D-pad-aware horizontal list
│       └── FocusableHorizontalScrollView.java  # Smooth scroll on focus
└── res/
    ├── layout/         # All screen and item layouts
    ├── drawable/       # Glass panels, focus rings, icons (vector XML)
    ├── values/         # strings, colors, styles, dimens
    └── anim/           # Fade and scale animations
```

## Building

1. Open the `glasstv-launcher` folder in Android Studio.
2. Wait for Gradle sync to complete.
3. Build → Generate Signed APK (or use `./gradlew assembleRelease`).
4. Sideload the APK onto your MXQ Pro 4K 5G via ADB or USB.

## YouTube API Setup

The launcher uses the YouTube Data API v3 to fetch recommendations.

1. Go to https://console.developers.google.com
2. Create a project and enable the **YouTube Data API v3**.
3. Generate an API key (restrict it to Android apps using your package name).
4. In the launcher, go to **Settings → YouTube API Key** and enter your key.
5. Without an API key, the launcher falls back to a built-in list of popular videos.

## Setting as Default Launcher

On first install, Android will ask which launcher to use. Select **GlassTV Launcher** and
choose **Always**. Alternatively, go to Settings → Apps → Default Apps → Home App.

## D-pad Navigation

| Button | Action |
|--------|--------|
| D-pad Left/Right | Navigate within video row or dock |
| D-pad Up | Move from dock → video row → top bar |
| D-pad Down | Move from top bar → video row → dock |
| OK / Enter | Open focused video or launch app |
| Back | Return to launcher (from settings) |

## Wallpaper

Go to **Settings → Change Wallpaper** to pick an image from your device storage,
or browse the auto-scanned gallery from DCIM/Pictures.

## Dock

The dock shows exactly 5 app icons. Go to **Settings → Manage Favorites** to add or
remove apps. Default apps (YouTube, Settings, Play Store, etc.) are pre-populated and
replaced automatically if not installed.

## Performance Notes

- No real-time blur is used — glass effect is achieved with transparency + gradient layers.
- Thumbnails are cached in an LRU `Bitmap` cache (1/8 of available heap).
- Thumbnails are loaded with `RGB_565` to halve memory usage vs `ARGB_8888`.
- The clock updates every 30 seconds, not every second, to reduce wakeups.
- `android:largeHeap="false"` is intentional to keep memory pressure low on the 2 GB RAM device.

## License

MIT
