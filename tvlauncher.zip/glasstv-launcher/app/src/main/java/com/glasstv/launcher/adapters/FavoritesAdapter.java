package com.glasstv.launcher.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.glasstv.launcher.R;
import com.glasstv.launcher.models.AppItem;

import java.util.List;

public class FavoritesAdapter {

    public interface OnFavoriteClickListener {
        void onFavoriteClicked(AppItem app);
        void onFavoriteFocused(AppItem app, View view, boolean focused);
    }

    private Context context;
    private List<AppItem> items;
    private OnFavoriteClickListener listener;
    private LayoutInflater inflater;

    public FavoritesAdapter(Context context, List<AppItem> items, OnFavoriteClickListener listener) {
        this.context = context;
        this.items = items;
        this.listener = listener;
        this.inflater = LayoutInflater.from(context);
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_favorite, parent, false);
        }

        ImageView appIcon = convertView.findViewById(R.id.app_icon);
        View focusRing = convertView.findViewById(R.id.focus_ring);

        final AppItem app = items.get(position);
        final View itemView = convertView;

        if (app.getIcon() != null) {
            appIcon.setImageDrawable(app.getIcon());
        } else {
            appIcon.setImageResource(R.drawable.ic_default_app);
        }

        focusRing.setVisibility(View.INVISIBLE);
        itemView.setFocusable(true);
        itemView.setClickable(true);

        itemView.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                focusRing.setVisibility(hasFocus ? View.VISIBLE : View.INVISIBLE);
                listener.onFavoriteFocused(app, v, hasFocus);
            }
        });

        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onFavoriteClicked(app);
            }
        });

        return convertView;
    }

    public int getCount() {
        return items.size();
    }
}
