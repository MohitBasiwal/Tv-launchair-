package com.glasstv.launcher;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.glasstv.launcher.adapters.AppPickerAdapter;
import com.glasstv.launcher.managers.FavoritesManager;
import com.glasstv.launcher.models.AppItem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class FavoritesManagerActivity extends Activity {

    private ListView appListView;
    private AppPickerAdapter adapter;
    private FavoritesManager favoritesManager;
    private List<AppItem> installedApps = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites_manager);

        favoritesManager = new FavoritesManager(this);
        appListView = findViewById(R.id.app_list);

        loadInstalledApps();

        appListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                AppItem app = installedApps.get(position);
                List<AppItem> favorites = favoritesManager.getFavoriteApps();
                boolean already = false;
                for (AppItem fav : favorites) {
                    if (fav.getPackageName().equals(app.getPackageName())) {
                        already = true;
                        break;
                    }
                }
                if (already) {
                    favoritesManager.removeFavorite(app.getPackageName());
                    app.setFavorite(false);
                    Toast.makeText(FavoritesManagerActivity.this,
                            getString(R.string.removed_from_favorites, app.getLabel()),
                            Toast.LENGTH_SHORT).show();
                } else {
                    if (favorites.size() >= FavoritesManager.MAX_FAVORITES) {
                        Toast.makeText(FavoritesManagerActivity.this,
                                R.string.max_favorites_reached, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    favoritesManager.addFavorite(app);
                    app.setFavorite(true);
                    Toast.makeText(FavoritesManagerActivity.this,
                            getString(R.string.added_to_favorites, app.getLabel()),
                            Toast.LENGTH_SHORT).show();
                }
                adapter.notifyDataSetChanged();
            }
        });

        appListView.requestFocus();
    }

    private void loadInstalledApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        List<AppItem> currentFavorites = favoritesManager.getFavoriteApps();

        installedApps.clear();
        for (ApplicationInfo info : apps) {
            if (pm.getLaunchIntentForPackage(info.packageName) != null) {
                String label = pm.getApplicationLabel(info).toString();
                Drawable icon = pm.getApplicationIcon(info);
                boolean isFavorite = false;
                for (AppItem fav : currentFavorites) {
                    if (fav.getPackageName().equals(info.packageName)) {
                        isFavorite = true;
                        break;
                    }
                }
                AppItem item = new AppItem(info.packageName, label, icon);
                item.setFavorite(isFavorite);
                installedApps.add(item);
            }
        }

        Collections.sort(installedApps, new Comparator<AppItem>() {
            @Override
            public int compare(AppItem a, AppItem b) {
                return a.getLabel().compareToIgnoreCase(b.getLabel());
            }
        });

        adapter = new AppPickerAdapter(this, installedApps);
        appListView.setAdapter(adapter);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
