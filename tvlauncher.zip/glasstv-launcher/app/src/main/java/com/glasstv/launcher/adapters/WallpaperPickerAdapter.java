package com.glasstv.launcher.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.glasstv.launcher.R;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WallpaperPickerAdapter extends BaseAdapter {

    public interface OnWallpaperSelectedListener {
        void onWallpaperSelected(String path);
    }

    private Context context;
    private List<String> paths;
    private OnWallpaperSelectedListener listener;
    private LayoutInflater inflater;
    private ExecutorService executor = Executors.newFixedThreadPool(3);

    public WallpaperPickerAdapter(Context context, List<String> paths,
                                   OnWallpaperSelectedListener listener) {
        this.context = context;
        this.paths = paths;
        this.listener = listener;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() { return paths.size(); }

    @Override
    public Object getItem(int position) { return paths.get(position); }

    @Override
    public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_wallpaper, parent, false);
        }
        final ImageView imageView = convertView.findViewById(R.id.wallpaper_thumbnail);
        final String path = paths.get(position);
        imageView.setImageResource(R.drawable.placeholder_wallpaper);
        imageView.setTag(path);

        final java.lang.ref.WeakReference<ImageView> ref = new java.lang.ref.WeakReference<>(imageView);
        executor.execute(new Runnable() {
            @Override
            public void run() {
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = 4;
                final Bitmap bmp = BitmapFactory.decodeFile(path, opts);
                if (bmp == null) return;
                ImageView iv = ref.get();
                if (iv != null) {
                    iv.post(new Runnable() {
                        @Override
                        public void run() {
                            ImageView iv2 = ref.get();
                            if (iv2 != null && path.equals(iv2.getTag())) {
                                iv2.setImageBitmap(bmp);
                            }
                        }
                    });
                }
            }
        });

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onWallpaperSelected(path);
            }
        });

        return convertView;
    }
}
