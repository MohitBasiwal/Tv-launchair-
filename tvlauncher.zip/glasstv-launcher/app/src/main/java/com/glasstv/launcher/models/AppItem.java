package com.glasstv.launcher.models;

import android.graphics.drawable.Drawable;

public class AppItem {
    private String packageName;
    private String label;
    private Drawable icon;
    private boolean isFavorite;
    private int dockPosition;

    public AppItem(String packageName, String label, Drawable icon) {
        this.packageName = packageName;
        this.label = label;
        this.icon = icon;
        this.isFavorite = false;
        this.dockPosition = -1;
    }

    public String getPackageName() { return packageName; }
    public String getLabel() { return label; }
    public Drawable getIcon() { return icon; }
    public boolean isFavorite() { return isFavorite; }
    public int getDockPosition() { return dockPosition; }

    public void setPackageName(String packageName) { this.packageName = packageName; }
    public void setLabel(String label) { this.label = label; }
    public void setIcon(Drawable icon) { this.icon = icon; }
    public void setFavorite(boolean favorite) { isFavorite = favorite; }
    public void setDockPosition(int dockPosition) { this.dockPosition = dockPosition; }
}
