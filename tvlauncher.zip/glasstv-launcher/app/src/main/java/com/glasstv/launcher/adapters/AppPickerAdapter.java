package com.glasstv.launcher.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.glasstv.launcher.R;
import com.glasstv.launcher.models.AppItem;

import java.util.List;

public class AppPickerAdapter extends BaseAdapter {

    private Context context;
    private List<AppItem> items;
    private LayoutInflater inflater;

    public AppPickerAdapter(Context context, List<AppItem> items) {
        this.context = context;
        this.items = items;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_app_picker, parent, false);
            holder = new ViewHolder();
            holder.icon = convertView.findViewById(R.id.app_icon);
            holder.label = convertView.findViewById(R.id.app_label);
            holder.checkBox = convertView.findViewById(R.id.app_checkbox);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        AppItem app = items.get(position);
        if (app.getIcon() != null) {
            holder.icon.setImageDrawable(app.getIcon());
        }
        holder.label.setText(app.getLabel());
        holder.checkBox.setChecked(app.isFavorite());

        return convertView;
    }

    private static class ViewHolder {
        ImageView icon;
        TextView label;
        CheckBox checkBox;
    }
}
