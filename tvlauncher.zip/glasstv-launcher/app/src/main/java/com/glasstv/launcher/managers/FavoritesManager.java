package com.glasstv.launcher.managers;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;

import com.glasstv.launcher.models.AppItem;

import java.util.ArrayList;
import java.util.List;

public class FavoritesManager {

    public static final int MAX_FAVORITES = 5;
    private static final String PREFS_NAME = "glasstv_favorites";
    private static final String KEY_FAVORITES = "favorites";
    private static final String SEPARATOR = ",";

    private Context context;
    private SharedPreferences prefs;

    private static final String[] DEFAULT_PACKAGES = {
        "com.google.android.youtube",
        "com.android.settings",
        "com.google.android.apps.tv.launcherclient",
        "com.android.vending",
        "com.google.android.gms"
    };

    public FavoritesManager(Context context) {
        this.context = context;
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        ensureDefaults();
    }

    private void ensureDefaults() {
        if (!prefs.contains(KEY_FAVORITES)) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < DEFAULT_PACKAGES.length; i++) {
                if (i > 0) sb.append(SEPARATOR);
                sb.append(DEFAULT_PACKAGES[i]);
            }
            prefs.edit().putString(KEY_FAVORITES, sb.toString()).apply();
        }
    }

    public List<AppItem> getFavoriteApps() {
        String saved = prefs.getString(KEY_FAVORITES, "");
        List<AppItem> result = new ArrayList<>();
        if (saved == null || saved.isEmpty()) return result;

        PackageManager pm = context.getPackageManager();
        String[] packages = saved.split(SEPARATOR);
        for (String pkg : packages) {
            pkg = pkg.trim();
            if (pkg.isEmpty()) continue;
            try {
                String label = pm.getApplicationLabel(
                        pm.getApplicationInfo(pkg, 0)).toString();
                Drawable icon = pm.getApplicationIcon(pkg);
                AppItem item = new AppItem(pkg, label, icon);
                item.setFavorite(true);
                result.add(item);
            } catch (PackageManager.NameNotFoundException e) {
            }
        }
        return result;
    }

    public void addFavorite(AppItem app) {
        List<AppItem> current = getFavoriteApps();
        if (current.size() >= MAX_FAVORITES) return;
        for (AppItem item : current) {
            if (item.getPackageName().equals(app.getPackageName())) return;
        }
        current.add(app);
        saveFavorites(current);
    }

    public void removeFavorite(String packageName) {
        List<AppItem> current = getFavoriteApps();
        for (int i = 0; i < current.size(); i++) {
            if (current.get(i).getPackageName().equals(packageName)) {
                current.remove(i);
                break;
            }
        }
        saveFavorites(current);
    }

    public void reorderFavorites(List<AppItem> newOrder) {
        saveFavorites(newOrder);
    }

    private void saveFavorites(List<AppItem> apps) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < apps.size(); i++) {
            if (i > 0) sb.append(SEPARATOR);
            sb.append(apps.get(i).getPackageName());
        }
        prefs.edit().putString(KEY_FAVORITES, sb.toString()).apply();
    }
}
