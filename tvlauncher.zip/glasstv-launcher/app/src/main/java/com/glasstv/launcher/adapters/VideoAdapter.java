package com.glasstv.launcher.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.glasstv.launcher.R;
import com.glasstv.launcher.models.VideoItem;
import com.glasstv.launcher.utils.ThumbnailCache;

import java.util.List;

public class VideoAdapter {

    public interface OnVideoFocusListener {
        void onVideoFocused(VideoItem item, View view);
        void onVideoUnfocused(VideoItem item, View view);
        void onVideoClicked(VideoItem item);
    }

    private Context context;
    private List<VideoItem> items;
    private OnVideoFocusListener listener;
    private LayoutInflater inflater;
    private ThumbnailCache thumbnailCache;

    public VideoAdapter(Context context, List<VideoItem> items, OnVideoFocusListener listener) {
        this.context = context;
        this.items = items;
        this.listener = listener;
        this.inflater = LayoutInflater.from(context);
        this.thumbnailCache = ThumbnailCache.getInstance();
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_video, parent, false);
            holder = new ViewHolder();
            holder.thumbnail = convertView.findViewById(R.id.video_thumbnail);
            holder.title = convertView.findViewById(R.id.video_title);
            holder.channel = convertView.findViewById(R.id.video_channel);
            holder.duration = convertView.findViewById(R.id.video_duration);
            holder.focusOverlay = convertView.findViewById(R.id.focus_overlay);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final VideoItem item = items.get(position);
        final View itemView = convertView;
        final ViewHolder finalHolder = holder;

        holder.title.setText(item.getTitle());
        holder.channel.setText(item.getChannelName());
        holder.duration.setText(item.getDuration());
        holder.focusOverlay.setVisibility(View.INVISIBLE);

        thumbnailCache.loadImage(item.getThumbnailUrl(), holder.thumbnail, R.drawable.placeholder_video);

        itemView.setFocusable(true);
        itemView.setClickable(true);

        itemView.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                finalHolder.focusOverlay.setVisibility(hasFocus ? View.VISIBLE : View.INVISIBLE);
                if (hasFocus) {
                    listener.onVideoFocused(item, v);
                } else {
                    listener.onVideoUnfocused(item, v);
                }
            }
        });

        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onVideoClicked(item);
            }
        });

        return convertView;
    }

    public int getCount() {
        return items.size();
    }

    private static class ViewHolder {
        ImageView thumbnail;
        TextView title;
        TextView channel;
        TextView duration;
        View focusOverlay;
    }
}
