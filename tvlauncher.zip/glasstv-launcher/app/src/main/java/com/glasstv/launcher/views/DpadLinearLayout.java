package com.glasstv.launcher.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;

public class DpadLinearLayout extends LinearLayout {

    public DpadLinearLayout(Context context) {
        super(context);
        init();
    }

    public DpadLinearLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public DpadLinearLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        setDescendantFocusability(FOCUS_AFTER_DESCENDANTS);
        setOrientation(HORIZONTAL);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            int code = event.getKeyCode();
            View focused = findFocus();
            if (focused == null) return super.dispatchKeyEvent(event);

            int index = indexOfChild(focused);
            int count = getChildCount();

            if (code == KeyEvent.KEYCODE_DPAD_RIGHT) {
                if (index < count - 1) {
                    getChildAt(index + 1).requestFocus();
                    scrollToFocused(index + 1);
                    return true;
                }
            } else if (code == KeyEvent.KEYCODE_DPAD_LEFT) {
                if (index > 0) {
                    getChildAt(index - 1).requestFocus();
                    scrollToFocused(index - 1);
                    return true;
                }
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private void scrollToFocused(int index) {
        View child = getChildAt(index);
        if (child == null) return;
        View parent = (View) getParent();
        if (parent instanceof android.widget.HorizontalScrollView) {
            android.widget.HorizontalScrollView hsv =
                    (android.widget.HorizontalScrollView) parent;
            hsv.smoothScrollTo(child.getLeft() - hsv.getWidth() / 2 + child.getWidth() / 2, 0);
        }
    }
}
