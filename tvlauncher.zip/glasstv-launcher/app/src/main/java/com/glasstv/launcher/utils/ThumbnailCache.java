package com.glasstv.launcher.utils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThumbnailCache {

    private static ThumbnailCache instance;
    private LruCache<String, Bitmap> memCache;
    private ExecutorService executor;

    private static final int MAX_POOL_SIZE = 4;

    private ThumbnailCache() {
        int maxMem = (int) (Runtime.getRuntime().maxMemory() / 1024);
        int cacheSize = maxMem / 8;
        memCache = new LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap value) {
                return value.getByteCount() / 1024;
            }
        };
        executor = Executors.newFixedThreadPool(MAX_POOL_SIZE);
    }

    public static synchronized ThumbnailCache getInstance() {
        if (instance == null) {
            instance = new ThumbnailCache();
        }
        return instance;
    }

    public void loadImage(String urlString, ImageView imageView, int placeholderRes) {
        if (urlString == null || urlString.isEmpty()) {
            imageView.setImageResource(placeholderRes);
            return;
        }
        Bitmap cached = memCache.get(urlString);
        if (cached != null) {
            imageView.setImageBitmap(cached);
            return;
        }
        imageView.setImageResource(placeholderRes);
        imageView.setTag(urlString);
        loadAsync(urlString, imageView);
    }

    private void loadAsync(final String urlString, final ImageView imageView) {
        final WeakReference<ImageView> ref = new WeakReference<>(imageView);
        executor.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap bmp = downloadBitmap(urlString);
                if (bmp == null) return;
                memCache.put(urlString, bmp);
                final Bitmap result = bmp;
                ImageView iv = ref.get();
                if (iv != null) {
                    iv.post(new Runnable() {
                        @Override
                        public void run() {
                            ImageView iv2 = ref.get();
                            if (iv2 != null && urlString.equals(iv2.getTag())) {
                                iv2.setImageBitmap(result);
                            }
                        }
                    });
                }
            }
        });
    }

    private Bitmap downloadBitmap(String urlString) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            conn.connect();
            if (conn.getResponseCode() != 200) return null;
            InputStream is = new BufferedInputStream(conn.getInputStream());
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeStream(is, null, opts);
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    public void clearCache() {
        memCache.evictAll();
    }

    public void shutdown() {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }
}
