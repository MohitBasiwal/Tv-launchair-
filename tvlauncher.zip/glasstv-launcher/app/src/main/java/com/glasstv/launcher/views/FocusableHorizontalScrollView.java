package com.glasstv.launcher.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.HorizontalScrollView;

public class FocusableHorizontalScrollView extends HorizontalScrollView {

    public FocusableHorizontalScrollView(Context context) {
        super(context);
        init();
    }

    public FocusableHorizontalScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public FocusableHorizontalScrollView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        setHorizontalScrollBarEnabled(false);
        setOverScrollMode(OVER_SCROLL_NEVER);
        setDescendantFocusability(FOCUS_AFTER_DESCENDANTS);
    }

    @Override
    public void requestChildFocus(View child, View focused) {
        super.requestChildFocus(child, focused);
        if (focused != null) {
            int x = focused.getLeft() - getWidth() / 2 + focused.getWidth() / 2;
            smoothScrollTo(Math.max(0, x), 0);
        }
    }
}
