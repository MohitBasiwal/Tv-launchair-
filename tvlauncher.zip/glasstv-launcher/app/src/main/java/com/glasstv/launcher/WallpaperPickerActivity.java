package com.glasstv.launcher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.View;
import android.widget.GridView;
import android.widget.Toast;

import com.glasstv.launcher.adapters.WallpaperPickerAdapter;
import com.glasstv.launcher.managers.WallpaperManager;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class WallpaperPickerActivity extends Activity {

    private static final int REQUEST_PICK_IMAGE = 1001;

    private GridView gridView;
    private WallpaperPickerAdapter adapter;
    private WallpaperManager wallpaperManager;
    private List<String> wallpaperPaths = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallpaper_picker);

        wallpaperManager = new WallpaperManager(this);
        gridView = findViewById(R.id.wallpaper_grid);

        View pickFromStorageBtn = findViewById(R.id.pick_from_storage);
        pickFromStorageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickImageFromStorage();
            }
        });
        pickFromStorageBtn.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                v.setSelected(hasFocus);
            }
        });

        loadWallpapers();
        pickFromStorageBtn.requestFocus();
    }

    private void loadWallpapers() {
        wallpaperPaths.clear();
        File dcim = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
        File pictures = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        addImagesFromDir(dcim);
        addImagesFromDir(pictures);

        adapter = new WallpaperPickerAdapter(this, wallpaperPaths, new WallpaperPickerAdapter.OnWallpaperSelectedListener() {
            @Override
            public void onWallpaperSelected(String path) {
                wallpaperManager.setWallpaper(path);
                Toast.makeText(WallpaperPickerActivity.this,
                        R.string.wallpaper_set, Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        gridView.setAdapter(adapter);
    }

    private void addImagesFromDir(File dir) {
        if (dir == null || !dir.exists()) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isFile()) {
                String name = f.getName().toLowerCase();
                if (name.endsWith(".jpg") || name.endsWith(".jpeg")
                        || name.endsWith(".png") || name.endsWith(".webp")) {
                    wallpaperPaths.add(f.getAbsolutePath());
                }
            }
        }
    }

    private void pickImageFromStorage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                String path = uri.getPath();
                if (path != null) {
                    wallpaperManager.setWallpaper(path);
                    Toast.makeText(this, R.string.wallpaper_set, Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
