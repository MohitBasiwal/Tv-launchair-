package com.glasstv.launcher.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TimeUtils {

    private static final SimpleDateFormat TIME_FORMAT =
            new SimpleDateFormat("h:mm a", Locale.US);
    private static final SimpleDateFormat DATE_FORMAT =
            new SimpleDateFormat("EEEE, MMMM d", Locale.US);

    public static String formatTime12Hour(Date date) {
        return TIME_FORMAT.format(date);
    }

    public static String formatDate(Date date) {
        return DATE_FORMAT.format(date);
    }
}
