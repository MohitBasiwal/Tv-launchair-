package com.glasstv.launcher;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.glasstv.launcher.adapters.FavoritesAdapter;
import com.glasstv.launcher.adapters.VideoAdapter;
import com.glasstv.launcher.managers.FavoritesManager;
import com.glasstv.launcher.managers.WallpaperManager;
import com.glasstv.launcher.models.AppItem;
import com.glasstv.launcher.models.VideoItem;
import com.glasstv.launcher.services.YouTubeRecommendationService;
import com.glasstv.launcher.utils.TimeUtils;
import com.glasstv.launcher.views.FocusableHorizontalScrollView;
import com.glasstv.launcher.views.DpadLinearLayout;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class LauncherActivity extends Activity implements
        VideoAdapter.OnVideoFocusListener,
        FavoritesAdapter.OnFavoriteClickListener {

    private static final String TAG = "GlassTVLauncher";
    private static final int CLOCK_UPDATE_INTERVAL = 30000;

    private RelativeLayout rootLayout;
    private ImageView wallpaperView;
    private View topBarPanel;
    private ImageView wifiIcon;
    private ImageView usbIcon;
    private TextView clockText;
    private TextView dateText;
    private ImageView settingsIcon;

    private View contentPanel;
    private DpadLinearLayout videoRowLayout;
    private View dockPanel;
    private DpadLinearLayout favoritesLayout;

    private VideoAdapter videoAdapter;
    private FavoritesAdapter favoritesAdapter;
    private FavoritesManager favoritesManager;
    private WallpaperManager wallpaperManager;
    private YouTubeRecommendationService youtubeService;

    private Handler clockHandler;
    private Handler uiHandler;
    private Runnable clockRunnable;

    private BroadcastReceiver wifiReceiver;
    private BroadcastReceiver usbReceiver;

    private List<VideoItem> videoItems = new ArrayList<>();
    private List<AppItem> favoriteApps = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(
            android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,
            android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        setContentView(R.layout.activity_launcher);

        initManagers();
        initViews();
        initClock();
        initReceivers();
        loadWallpaper();
        loadFavorites();
        loadVideos();
    }

    private void initManagers() {
        favoritesManager = new FavoritesManager(this);
        wallpaperManager = new WallpaperManager(this);
        youtubeService = new YouTubeRecommendationService(this);
        uiHandler = new Handler(Looper.getMainLooper());
        clockHandler = new Handler(Looper.getMainLooper());
    }

    private void initViews() {
        rootLayout = findViewById(R.id.root_layout);
        wallpaperView = findViewById(R.id.wallpaper_view);

        topBarPanel = findViewById(R.id.top_bar_panel);
        wifiIcon = findViewById(R.id.wifi_icon);
        usbIcon = findViewById(R.id.usb_icon);
        clockText = findViewById(R.id.clock_text);
        dateText = findViewById(R.id.date_text);
        settingsIcon = findViewById(R.id.settings_icon);

        contentPanel = findViewById(R.id.content_panel);
        videoRowLayout = findViewById(R.id.video_row_layout);

        dockPanel = findViewById(R.id.dock_panel);
        favoritesLayout = findViewById(R.id.favorites_layout);

        settingsIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSettings();
            }
        });

        settingsIcon.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                animateFocus(v, hasFocus);
            }
        });
    }

    private void initClock() {
        updateClock();
        clockRunnable = new Runnable() {
            @Override
            public void run() {
                updateClock();
                clockHandler.postDelayed(this, CLOCK_UPDATE_INTERVAL);
            }
        };
        clockHandler.postDelayed(clockRunnable, CLOCK_UPDATE_INTERVAL);
    }

    private void updateClock() {
        Date now = new Date();
        clockText.setText(TimeUtils.formatTime12Hour(now));
        dateText.setText(TimeUtils.formatDate(now));
        updateWifiStatus();
    }

    private void updateWifiStatus() {
        WifiManager wifiManager = (WifiManager) getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE);
        if (wifiManager != null && wifiManager.isWifiEnabled()) {
            int level = wifiManager.getConnectionInfo().getRssi();
            int strength = WifiManager.calculateSignalLevel(level, 4);
            switch (strength) {
                case 0: wifiIcon.setImageResource(R.drawable.ic_wifi_0); break;
                case 1: wifiIcon.setImageResource(R.drawable.ic_wifi_1); break;
                case 2: wifiIcon.setImageResource(R.drawable.ic_wifi_2); break;
                case 3: wifiIcon.setImageResource(R.drawable.ic_wifi_3); break;
                default: wifiIcon.setImageResource(R.drawable.ic_wifi_3); break;
            }
            wifiIcon.setVisibility(View.VISIBLE);
        } else {
            wifiIcon.setImageResource(R.drawable.ic_wifi_off);
        }
    }

    private void initReceivers() {
        wifiReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                updateWifiStatus();
            }
        };
        IntentFilter wifiFilter = new IntentFilter();
        wifiFilter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        wifiFilter.addAction(WifiManager.RSSI_CHANGED_ACTION);
        registerReceiver(wifiReceiver, wifiFilter);

        usbReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (Intent.ACTION_MEDIA_MOUNTED.equals(action)) {
                    usbIcon.setVisibility(View.VISIBLE);
                } else if (Intent.ACTION_MEDIA_UNMOUNTED.equals(action)
                        || Intent.ACTION_MEDIA_REMOVED.equals(action)) {
                    usbIcon.setVisibility(View.GONE);
                }
            }
        };
        IntentFilter usbFilter = new IntentFilter();
        usbFilter.addAction(Intent.ACTION_MEDIA_MOUNTED);
        usbFilter.addAction(Intent.ACTION_MEDIA_UNMOUNTED);
        usbFilter.addAction(Intent.ACTION_MEDIA_REMOVED);
        usbFilter.addDataScheme("file");
        registerReceiver(usbReceiver, usbFilter);
    }

    private void loadWallpaper() {
        String wallpaperPath = wallpaperManager.getCurrentWallpaperPath();
        if (wallpaperPath != null) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 2;
            Bitmap bmp = BitmapFactory.decodeFile(wallpaperPath, options);
            if (bmp != null) {
                wallpaperView.setImageBitmap(bmp);
                return;
            }
        }
        wallpaperView.setImageResource(R.drawable.default_wallpaper);
    }

    private void loadFavorites() {
        favoriteApps = favoritesManager.getFavoriteApps();
        favoritesAdapter = new FavoritesAdapter(this, favoriteApps, this);
        favoritesLayout.removeAllViews();
        for (int i = 0; i < favoriteApps.size(); i++) {
            View itemView = favoritesAdapter.getView(i, null, favoritesLayout);
            favoritesLayout.addView(itemView);
        }
        if (!favoriteApps.isEmpty()) {
            favoritesLayout.getChildAt(0).requestFocus();
        }
    }

    private void loadVideos() {
        youtubeService.fetchRecommendations(new YouTubeRecommendationService.Callback() {
            @Override
            public void onSuccess(final List<VideoItem> items) {
                uiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        videoItems = items;
                        populateVideoRow();
                    }
                });
            }

            @Override
            public void onError(String error) {
                uiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        loadTrendingVideos();
                    }
                });
            }
        });
    }

    private void loadTrendingVideos() {
        youtubeService.fetchTrending(new YouTubeRecommendationService.Callback() {
            @Override
            public void onSuccess(final List<VideoItem> items) {
                uiHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        videoItems = items;
                        populateVideoRow();
                    }
                });
            }

            @Override
            public void onError(String error) {
            }
        });
    }

    private void populateVideoRow() {
        videoAdapter = new VideoAdapter(this, videoItems, this);
        videoRowLayout.removeAllViews();
        for (int i = 0; i < videoItems.size(); i++) {
            View itemView = videoAdapter.getView(i, null, videoRowLayout);
            videoRowLayout.addView(itemView);
        }
    }

    public void animateFocus(View view, boolean hasFocus) {
        if (hasFocus) {
            view.animate()
                .scaleX(1.18f)
                .scaleY(1.18f)
                .translationY(-12f)
                .setDuration(250)
                .start();
        } else {
            view.animate()
                .scaleX(1.0f)
                .scaleY(1.0f)
                .translationY(0f)
                .setDuration(250)
                .start();
        }
    }

    @Override
    public void onVideoFocused(VideoItem item, View view) {
        animateFocus(view, true);
    }

    @Override
    public void onVideoUnfocused(VideoItem item, View view) {
        animateFocus(view, false);
    }

    @Override
    public void onVideoClicked(VideoItem item) {
        openYouTubeVideo(item.getVideoId());
    }

    @Override
    public void onFavoriteClicked(AppItem app) {
        try {
            Intent launchIntent = getPackageManager()
                    .getLaunchIntentForPackage(app.getPackageName());
            if (launchIntent != null) {
                startActivity(launchIntent);
            }
        } catch (Exception e) {
        }
    }

    @Override
    public void onFavoriteFocused(AppItem app, View view, boolean focused) {
        animateFocus(view, focused);
    }

    private void openYouTubeVideo(String videoId) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    android.net.Uri.parse("vnd.youtube:" + videoId));
            intent.setPackage("com.google.android.youtube");
            intent.putExtra("force_fullscreen", true);
            startActivity(intent);
        } catch (Exception e) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        android.net.Uri.parse("https://www.youtube.com/watch?v=" + videoId));
                startActivity(intent);
            } catch (Exception ex) {
            }
        }
    }

    private void openSettings() {
        startActivity(new Intent(this, SettingsActivity.class));
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
                handleDpadUp();
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                handleDpadDown();
                return true;
            case KeyEvent.KEYCODE_BACK:
                return true;
            case KeyEvent.KEYCODE_HOME:
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void handleDpadUp() {
        View focused = getCurrentFocus();
        if (focused != null && isInDock(focused)) {
            if (videoRowLayout.getChildCount() > 0) {
                videoRowLayout.getChildAt(0).requestFocus();
            }
        } else if (focused != null && isInVideoRow(focused)) {
            settingsIcon.requestFocus();
        }
    }

    private void handleDpadDown() {
        View focused = getCurrentFocus();
        if (focused != null && isInVideoRow(focused)) {
            if (favoritesLayout.getChildCount() > 0) {
                favoritesLayout.getChildAt(0).requestFocus();
            }
        } else if (focused != null && isInTopBar(focused)) {
            if (videoRowLayout.getChildCount() > 0) {
                videoRowLayout.getChildAt(0).requestFocus();
            }
        }
    }

    private boolean isInDock(View v) {
        return isDescendantOf(v, dockPanel);
    }

    private boolean isInVideoRow(View v) {
        return isDescendantOf(v, videoRowLayout);
    }

    private boolean isInTopBar(View v) {
        return isDescendantOf(v, topBarPanel);
    }

    private boolean isDescendantOf(View child, View parent) {
        if (child == parent) return true;
        android.view.ViewParent p = child.getParent();
        while (p != null) {
            if (p == parent) return true;
            p = p.getParent();
        }
        return false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateClock();
        loadFavorites();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (clockHandler != null && clockRunnable != null) {
            clockHandler.removeCallbacks(clockRunnable);
        }
        try {
            unregisterReceiver(wifiReceiver);
            unregisterReceiver(usbReceiver);
        } catch (Exception e) {
        }
        if (youtubeService != null) {
            youtubeService.shutdown();
        }
    }
}
