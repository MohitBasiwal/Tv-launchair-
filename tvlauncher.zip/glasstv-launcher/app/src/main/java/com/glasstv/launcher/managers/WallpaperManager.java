package com.glasstv.launcher.managers;

import android.content.Context;
import android.content.SharedPreferences;

public class WallpaperManager {

    private static final String PREFS_NAME = "glasstv_wallpaper";
    private static final String KEY_WALLPAPER_PATH = "wallpaper_path";

    private Context context;
    private SharedPreferences prefs;

    public WallpaperManager(Context context) {
        this.context = context;
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public String getCurrentWallpaperPath() {
        return prefs.getString(KEY_WALLPAPER_PATH, null);
    }

    public void setWallpaper(String absolutePath) {
        prefs.edit().putString(KEY_WALLPAPER_PATH, absolutePath).apply();
    }

    public void clearWallpaper() {
        prefs.edit().remove(KEY_WALLPAPER_PATH).apply();
    }
}
