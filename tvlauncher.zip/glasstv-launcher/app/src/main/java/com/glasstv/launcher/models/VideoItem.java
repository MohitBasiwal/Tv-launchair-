package com.glasstv.launcher.models;

public class VideoItem {
    private String videoId;
    private String title;
    private String channelName;
    private String thumbnailUrl;
    private String viewCount;
    private String duration;

    public VideoItem(String videoId, String title, String channelName,
                     String thumbnailUrl, String viewCount, String duration) {
        this.videoId = videoId;
        this.title = title;
        this.channelName = channelName;
        this.thumbnailUrl = thumbnailUrl;
        this.viewCount = viewCount;
        this.duration = duration;
    }

    public String getVideoId() { return videoId; }
    public String getTitle() { return title; }
    public String getChannelName() { return channelName; }
    public String getThumbnailUrl() { return thumbnailUrl; }
    public String getViewCount() { return viewCount; }
    public String getDuration() { return duration; }

    public void setVideoId(String videoId) { this.videoId = videoId; }
    public void setTitle(String title) { this.title = title; }
    public void setChannelName(String channelName) { this.channelName = channelName; }
    public void setThumbnailUrl(String thumbnailUrl) { this.thumbnailUrl = thumbnailUrl; }
    public void setViewCount(String viewCount) { this.viewCount = viewCount; }
    public void setDuration(String duration) { this.duration = duration; }
}
