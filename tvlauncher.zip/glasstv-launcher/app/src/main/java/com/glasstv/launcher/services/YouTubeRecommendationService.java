package com.glasstv.launcher.services;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;

import com.glasstv.launcher.models.VideoItem;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class YouTubeRecommendationService {

    private static final String TAG = "YouTubeService";
    private static final String PREFS_NAME = "glasstv_youtube";
    private static final String KEY_API_KEY = "youtube_api_key";
    private static final String BASE_URL = "https://www.googleapis.com/youtube/v3/";
    private static final int FETCH_LIMIT = 12;
    private static final int TIMEOUT_MS = 10000;

    private Context context;
    private SharedPreferences prefs;
    private ExecutorService executor;

    public interface Callback {
        void onSuccess(List<VideoItem> items);
        void onError(String error);
    }

    public YouTubeRecommendationService(Context context) {
        this.context = context;
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.executor = Executors.newSingleThreadExecutor();
    }

    public void setApiKey(String apiKey) {
        prefs.edit().putString(KEY_API_KEY, apiKey).apply();
    }

    public String getApiKey() {
        return prefs.getString(KEY_API_KEY, "");
    }

    public void fetchRecommendations(final Callback callback) {
        String apiKey = getApiKey();
        if (apiKey == null || apiKey.isEmpty()) {
            callback.onError("No API key configured");
            return;
        }
        fetchFromUrl(
            BASE_URL + "videos?part=snippet,contentDetails,statistics"
                + "&chart=mostPopular"
                + "&maxResults=" + FETCH_LIMIT
                + "&regionCode=US"
                + "&videoCategoryId=0"
                + "&key=" + apiKey,
            callback
        );
    }

    public void fetchTrending(final Callback callback) {
        String apiKey = getApiKey();
        if (apiKey == null || apiKey.isEmpty()) {
            fetchFallbackContent(callback);
            return;
        }
        fetchFromUrl(
            BASE_URL + "videos?part=snippet,contentDetails,statistics"
                + "&chart=mostPopular"
                + "&maxResults=" + FETCH_LIMIT
                + "&regionCode=US"
                + "&key=" + apiKey,
            callback
        );
    }

    private void fetchFromUrl(final String urlString, final Callback callback) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL(urlString);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(TIMEOUT_MS);
                    conn.setReadTimeout(TIMEOUT_MS);
                    conn.connect();

                    if (conn.getResponseCode() != 200) {
                        callback.onError("HTTP " + conn.getResponseCode());
                        return;
                    }

                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                    }
                    reader.close();
                    conn.disconnect();

                    List<VideoItem> items = parseVideoResponse(sb.toString());
                    callback.onSuccess(items);
                } catch (Exception e) {
                    Log.e(TAG, "Fetch error: " + e.getMessage());
                    callback.onError(e.getMessage());
                }
            }
        });
    }

    private List<VideoItem> parseVideoResponse(String json) throws Exception {
        List<VideoItem> items = new ArrayList<>();
        JSONObject root = new JSONObject(json);
        JSONArray itemsArray = root.getJSONArray("items");

        for (int i = 0; i < itemsArray.length(); i++) {
            JSONObject item = itemsArray.getJSONObject(i);
            String videoId = item.getString("id");
            JSONObject snippet = item.getJSONObject("snippet");
            String title = snippet.getString("title");
            String channelName = snippet.optString("channelTitle", "");

            JSONObject thumbnails = snippet.getJSONObject("thumbnails");
            String thumbUrl = "";
            if (thumbnails.has("maxres")) {
                thumbUrl = thumbnails.getJSONObject("maxres").getString("url");
            } else if (thumbnails.has("high")) {
                thumbUrl = thumbnails.getJSONObject("high").getString("url");
            } else if (thumbnails.has("medium")) {
                thumbUrl = thumbnails.getJSONObject("medium").getString("url");
            }

            String viewCount = "";
            if (item.has("statistics")) {
                viewCount = item.getJSONObject("statistics").optString("viewCount", "");
            }

            String duration = "";
            if (item.has("contentDetails")) {
                duration = item.getJSONObject("contentDetails").optString("duration", "");
                duration = formatIsoDuration(duration);
            }

            items.add(new VideoItem(videoId, title, channelName, thumbUrl, viewCount, duration));
        }
        return items;
    }

    private String formatIsoDuration(String iso) {
        if (iso == null || iso.isEmpty()) return "";
        iso = iso.replace("PT", "");
        int hours = 0, minutes = 0, seconds = 0;
        if (iso.contains("H")) {
            hours = Integer.parseInt(iso.substring(0, iso.indexOf("H")));
            iso = iso.substring(iso.indexOf("H") + 1);
        }
        if (iso.contains("M")) {
            minutes = Integer.parseInt(iso.substring(0, iso.indexOf("M")));
            iso = iso.substring(iso.indexOf("M") + 1);
        }
        if (iso.contains("S")) {
            seconds = Integer.parseInt(iso.substring(0, iso.indexOf("S")));
        }
        if (hours > 0) {
            return String.format("%d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%d:%02d", minutes, seconds);
        }
    }

    private void fetchFallbackContent(final Callback callback) {
        List<VideoItem> fallback = new ArrayList<>();
        String[][] data = {
            {"dQw4w9WgXcQ", "Rick Astley - Never Gonna Give You Up", "Rick Astley",
             "https://img.youtube.com/vi/dQw4w9WgXcQ/hqdefault.jpg", "1.4B", "3:33"},
            {"9bZkp7q19f0", "PSY - GANGNAM STYLE", "officialpsy",
             "https://img.youtube.com/vi/9bZkp7q19f0/hqdefault.jpg", "5.2B", "4:12"},
            {"kJQP7kiw5Fk", "Luis Fonsi - Despacito", "LuisFonsiVEVO",
             "https://img.youtube.com/vi/kJQP7kiw5Fk/hqdefault.jpg", "8.2B", "4:42"},
            {"RgKAFK5djSk", "Wiz Khalifa - See You Again", "WizKhalifaVEVO",
             "https://img.youtube.com/vi/RgKAFK5djSk/hqdefault.jpg", "5.9B", "3:59"},
            {"JGwWNGJdvx8", "Ed Sheeran - Shape of You", "EdSheeranVEVO",
             "https://img.youtube.com/vi/JGwWNGJdvx8/hqdefault.jpg", "5.7B", "3:54"},
            {"OPf0YbXqDm0", "Mark Ronson - Uptown Funk", "MarkRonsonVEVO",
             "https://img.youtube.com/vi/OPf0YbXqDm0/hqdefault.jpg", "4.6B", "4:31"},
            {"hT_nvWreIhg", "OneRepublic - Counting Stars", "OneRepublicVEVO",
             "https://img.youtube.com/vi/hT_nvWreIhg/hqdefault.jpg", "3.5B", "4:17"},
            {"YqeW9_5kURI", "Justin Bieber - Baby", "JustinBieberVEVO",
             "https://img.youtube.com/vi/YqeW9_5kURI/hqdefault.jpg", "2.8B", "3:41"},
        };
        for (String[] d : data) {
            fallback.add(new VideoItem(d[0], d[1], d[2], d[3], d[4], d[5]));
        }
        callback.onSuccess(fallback);
    }

    public void shutdown() {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }
}
